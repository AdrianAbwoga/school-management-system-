<nav class="main-nav w-100">
    <div class="logo-div">
        <img src="images/logo2.png" alt="">
    </div>

    <div class="categories w-75">
        <div class=""></div>
        <a href="/"><button class="nav_btn w-100"><span class="hov"></span> HOME</button></a>
        

       
    </div>
</nav>