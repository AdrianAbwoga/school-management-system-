<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    
    

    <!-- Fontawesome icons cdn link -->
    <script src="https://kit.fontawesome.com/db540a34d6.js" crossorigin="anonymous"></script>

    <link rel="stylesheet" href="/css/student.css">
    <title>kinondoni</title>
</head>

<body>
    <nav class="main-nav w-100">
        <div class="logo-div">
            <img src="/images/logo2.png" alt="">
        </div>

        <div class="categories w-75">
            <div class=""></div>
            <div class=""></div>
            <div class=""></div>
            <a href="student" class="w-100"><button class="nav_btn w-100"><span class="hov"></span> BACK</button></a>

            <div class="menu-div">
                <h3 class="ps-4"><?php echo e($LoggedUserInfo['stud_name']); ?></h3>
            </div>
        </div>
    </nav>
    <section class="main-section w-100 m-0">
        <div class="header w-75">
            <h3>AVAILABLE FOR REGISTRATION</h3>
            <hr>
        </div>
        <?php if(Session::get('success')): ?>
        <div class="alert alert-success">
            <?php echo e(Session::get('success')); ?>

        </div>
        <?php endif; ?>

        <?php if(Session::get('fail')): ?>
        <div class="alert alert-danger">
            <?php echo e(Session::get('fail')); ?>

        </div>
        <?php endif; ?>
        <div class="registration-section w-75">
        
            <?php $__currentLoopData = $unit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="unit-card-reg">
                <div class="card-details w-100">
                    <h6>UNIT: </h6>
                    <h4><?php echo e($item->unit_name); ?></h4>
                    <p>Chapters: <span class="chapters"><?php echo e($item->unit_chapters); ?></span></p>
                    
                    <hr class="w-50">
                    <span class="chapters"><?php echo e($item->unit_desc); ?></span>
                    <hr>
                   

                </div>
                <form action="<?php echo e(url('reg_unit/'.$item->id )); ?>" method="post"><?php echo csrf_field(); ?><button class="register-btn">REGISTER</button></form>

            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
   
</body>

</html><?php /**PATH C:\xampp\htdocs\first_school-master\first_school-master\resources\views//student/unit_reg.blade.php ENDPATH**/ ?>