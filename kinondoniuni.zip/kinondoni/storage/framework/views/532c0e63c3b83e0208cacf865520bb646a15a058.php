<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Fontawesome icons cdn link -->
    <script src="https://kit.fontawesome.com/db540a34d6.js" crossorigin="anonymous"></script>

    <link rel="stylesheet" href="css/login.css">
    <title>Kinondoni login</title>
</head>

<body>
<nav class="main-nav w-100">
    <div class="logo-div">
        <img src="images/logo2.png" alt="">
    </div>

    <div class="categories w-75">
        <div class=""></div>
        <a href="/"><button class="nav_btn w-100"><span class="hov"></span> HOME</button></a>
        

       
    </div>
</nav>
    <section class="login-body w-100">
        <form action="<?php echo e(route('auth.check')); ?>" method="POST" class="form-control p-4 w-50">
            <?php echo csrf_field(); ?>
            <div class="usr-input w-100">
                <h2>LOGIN</h2>
                <hr>
            </div>
            <?php if(Session::get('success')): ?>
            <div class="alert alert-success">
                <?php echo e(Session::get('success')); ?>

            </div>
            <?php endif; ?>

            <?php if(Session::get('fail')): ?>
            <div class="alert alert-danger">
                <?php echo e(Session::get('fail')); ?>

            </div>
            <?php endif; ?>
            <div class="usr_input w-100">
                
                <input type="email" name="email" required placeholder="Email" class="form-control" value="" placeholder="Enter your email here:">
                <span class="text-danger"><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
            </div>
            <div class="usr_input w-100">
                
                <input type="password" name="password" required class="form-control" value="" placeholder="password">
                <span class="text-danger"><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
            </div>
            <div class="usr_input w-100">
              
            </div>
            <button class="btn btn-secondary p-2 m-1 w-100" type="submit">login</button>
        </form>
    </section>


    

</body>

</html><?php /**PATH C:\xampp\htdocs\first_school-master\first_school-master\resources\views/login.blade.php ENDPATH**/ ?>