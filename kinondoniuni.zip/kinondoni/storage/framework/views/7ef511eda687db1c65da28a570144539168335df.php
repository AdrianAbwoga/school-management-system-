<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>

    <!-- Fontawesome icons cdn link -->
    <script src="https://kit.fontawesome.com/db540a34d6.js" crossorigin="anonymous"></script>

    <link rel="stylesheet" href="css/admin.css">
    <script src="/JS/admin.js" defer></script>
    <title>KINONDONI admin</title>
</head>

<body>
    <nav class="admin-nav w-100">
        <div class="logo-div">
            <img src="images/logo2.png" alt="">
        </div>

        <div class="categories">
            <button class="nav_btn"><span class="text">STUDENTS</span><span>STUDENTS</span></button>
            <button class="nav_btn"><span class="text">STAFF</span><span>STAFF</span></button>
            <button class="nav_btn"><span class="text">COURSES</span><span>COURSES</span></button>
            
            <a href="<?php echo e(route('logout')); ?>"><button class="nav_btn"><span class="text">LOGOUT</span><span>LOGOUT</span></button></a>
        </div>
        <div class="admin-profile pe-4">
            <h4><?php echo e($LoggedUserInfo['staff_name']); ?></h4>
        </div>
    </nav>
    <section class="target target-selected w-100">
        <div class="header w-100 p-3">
            <h3>Students</h3>
            <hr>
        </div>
        <div class="main-panel w-100">
            <div class="category-summary">
                <div class="buttons-list w-100">
                    <button class="btn-option selected">GENERAL <span class="fragment"></span></button>
                    <a href="register"><button class="btn-option">ADD STUDENT <span class="fragment"></span></button></a>
                </div>
            </div>
            <div class="category-tables">

                <div class="panel active w-100">
                    <div class="cat-head w-100">
                        
                        <hr class="w-100">
                    </div>
                    <div class="table-section w-100">
                        <table class="table table-dark table-striped w-100">
                            <thead class="table-thead">
                                <tr>
                                    
                                    <th scope="col">NAME</th>
                                    <th scope="col">EMAIL</th>
                                    <th scope="col">STUDENT ID</th>
                                    <th scope="col">OPTIONS</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $student_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                   
                                    <td><?php echo e($item->stud_name); ?></td>
                                    <td><?php echo e($item->stud_email); ?></td>
                                    <td><?php echo e($item->stud_id); ?></td>
                                    <td>
                                        <div class="options">
                                            <a href="<?php echo e(url('edit-student/'.$item->stud_id)); ?>"><button class="btn btn-warning"><i class="fa-solid fa-pen-to-square"></i></button></a>
                                            <a href="<?php echo e(url('delete-student/'.$item->stud_id)); ?>"><button class="btn btn-danger"><i class="fa-solid fa-trash"></i></button></a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>


            </div>
        </div>
    </section>
    <section class="target w-100">
        <div class="header w-100 p-3">
            <h3>Staff</h3>
            <hr>
        </div>
        <div class="main-panel w-100">
            <div class="category-summary">
                <div class="buttons-list w-100">
                    <button class="btn-staff btn_side_selected">TABLE <span class="fragment"></span></button>
                    <button class="btn-staff">ADD STAFF <span class="fragment"></span></button>
                </div>
            </div>
            <div class="category-tables">
                <div class="panel-staff staff-active w-100">
                    <div class="cat-head w-100">
                        
                        <hr class="w-100">
                    </div>
                    <?php if(Session::get('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(Session::get('success')); ?>

                    </div>
                    <hr>
                    <?php endif; ?>

                    <?php if(Session::get('fail')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(Session::get('fail')); ?>

                    </div>
                    <hr>
                    <?php endif; ?>
                    <div class="table-section w-100">
                        <table class="table table-dark table-striped w-100">
                            <thead class="table-thead">
                                <tr>
                                    
                                    <th scope="col">STAFF NAME</th>
                                    <th scope="col">STAFF EMAIL</th>
                                    <th scope="col">STAFF ID</th>
                                    <th scope="col">OPTIONS</th>
                                </tr>
                            </thead>
                            <tbody class="">
                                <?php echo csrf_field(); ?>
                                <?php $__currentLoopData = $staff_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    
                                    <td><?php echo e($item->staff_name); ?></td>
                                    <td><?php echo e($item->staff_email); ?></td>
                                    <td><?php echo e($item->staff_role); ?></td>
                                    <td>
                                        <div class="options">
                                            <a href="<?php echo e(url('edit-student/'.$item->stud_id)); ?>"><button class="btn btn-warning"><i class="fa-solid fa-pen-to-square"></i></button></a>
                                            <a href="<?php echo e(url('delete-staff/'.$item->staff_id)); ?>"><button class="btn btn-danger"><i class="fa-solid fa-trash"></i></button></a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="panel-staff w-100">
                    <div class="cat-head w-100">
                        <h4>ADD STAFF</h4>
                        <hr class="w-100">
                    </div>
                    <form action="<?php echo e(route('auth.add-staff')); ?>" class="w-100" method="post">

                        <?php echo csrf_field(); ?>
                        <?php if(Session::get('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(Session::get('success')); ?>

                        </div>
                        <hr>
                        <?php endif; ?>

                        <?php if(Session::get('fail')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(Session::get('fail')); ?>

                        </div>
                        <hr>
                        <?php endif; ?>
                        <div class="form-input w-100">
                            <label for="name">NAME:</label>
                            <input type="text" class="form-control w-75" id="name" name="name" />
                        </div>
                        <hr>
                        <div class="form-input w-100">
                            <label for="name">EMAIL:</label>
                            <input type="email" class="form-control w-75" id="email" name="email" />
                        </div>
                        <hr>
                        <div class="form-input w-100">
                            <label for="name">PASSWORD:</label>
                            <input type="password" class="form-control w-75" id="password" name="password" />
                        </div>
                        <hr>
                        <div class="form-input w-100">
                            <label for="password">CONFIRM PASSWORD:</label>
                            <input type="password" class="form-control w-75" id="con_pass" name="con_pass" />
                        </div>
                        <hr>
                        <div class="form-input w-100">
                            <label for="password">Role:</label>
                            <select name="role_id" class="form-control w-25" id="">
                                <option value="2" selected>TEACHER</option>
                                <option value="1">MANAGER</option>
                            </select>
                        </div>
                        <hr>
                        <div class="form-input w-100">
                            <button class="btn btn-primary" type="submit">ADD STAFF</button>
                        </div>


                    </form>

                </div>



            </div>
        </div>

    </section>
    <section class="target w-100">
        <div class="header w-100 p-3">
            <h3>COURSES</h3>
            <hr>
        </div>
        <div class="main-panel w-100">
            <div class="category-summary">
                <div class="buttons-list w-100">
                    <button class="course-btn course-btn-selected">ALL COURSES <span class="fragment"></span></button>
                    <button class="course-btn">ADD COURSES <span class="fragment"></span></button>
                </div>
            </div>
            <div class="category-tables">

                <div class="course-panel course-panel-selected w-100">
                    <div class="cat-head w-100">
                        <h4>ALL COURSES</h4>
                        <hr class="w-100">
                    </div>
                    <div class="table-section w-100">
                        <?php if(Session::get('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(Session::get('success')); ?>

                        </div>
                        <?php endif; ?>

                        <?php if(Session::get('fail')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(Session::get('fail')); ?>

                        </div>
                        <?php endif; ?>
                        <table class="table table-dark table-striped w-100">
                            <thead class="table-thead">
                                <tr>
                                    <th scope="row">#</th>
                                    <th scope="col">COURSE NAME</th>
                                    <th scope="col">COURSE CODE</th>
                                    <th scope="col">DESCRIPTION</th>

                                    <th scope="col">CHAPTERS</th>
                                    <th scope="col">LECTURER</th>
                                    <th scope="col">START DAY</th>

                                    <th scope="col">OPTIONS</th>
                                </tr>
                            </thead>
                            <tbody class="">
                                <?php echo csrf_field(); ?>
                                <?php $__currentLoopData = $unit_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td scope="row"><?php echo e($item->id); ?></td>
                                    <td><?php echo e($item->unit_name); ?></td>
                                    <td><?php echo e($item->unit_code); ?></td>
                                    <td><?php echo e($item->unit_desc); ?></td>
                                    <td><?php echo e($item->unit_chapters); ?></td>
                                    <td><?php echo e($item->unit_lecturer); ?></td>
                                    <td><?php echo e($item->created_at); ?></td>
                                    <td>
                                        <a href="<?php echo e(url('delete-unit/'.$item->id)); ?>"><button class="btn btn-danger"><i class="fa-solid fa-trash"></i></button></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="course-panel w-100">
                    <div class="cat-head w-100">
                        <h4>ADD COURSES FORM</h4>
                        <hr class="w-100">
                    </div>
                    <div class="table-section w-100">
                        <?php if(Session::get('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(Session::get('success')); ?>

                        </div>
                        <hr>
                        <?php endif; ?>

                        <?php if(Session::get('fail')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(Session::get('fail')); ?>

                        </div>
                        <hr>
                        <?php endif; ?>


                        <div class="form-holder w-100 p-4">
                            <form action="<?php echo e(route('auth.add-unit')); ?>" method="post" class="form-control w-75 py-4 ">
                                <?php echo csrf_field(); ?>
                                <div class="form-input w-100">
                                    <label for="unit_name">Course name:</label>
                                    <input type="text" name="unit_name" class="form-control w-75">
                                    <span class="text-danger"><?php $__errorArgs = ['unit_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                                </div>
                                <hr>
                                <div class="form-input w-100">
                                    <label for="unit_desc">Course description:</label>
                                    <textarea class="form-control w-75" name="unit_desc" rows="5" id="comment"></textarea>
                                    <span class="text-danger"><?php $__errorArgs = ['unit_desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                                </div>
                                <hr>
                                <div class="form-input w-100">
                                    <label for="unit_name">Course code:</label>
                                    <input type="text" name="unit_code" class="form-control w-75">
                                    <span class="text-danger"><?php $__errorArgs = ['unit_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                                </div>
                                <hr>
                                <div class="form-input w-100">
                                    <label for="unit_name">No of chapters:</label>
                                    <input type="number" name="unit_chapters" class="form-control w-75">
                                    <span class="text-danger"><?php $__errorArgs = ['unit_chapters'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                                </div>
                                <hr>
                                <div class="form-input w-100">
                                    <label for="unit_name">Lecturer:</label>
                                    <select name="unit_lec" id="" class="form-control w-75">
                                        <?php $__currentLoopData = $staff_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lecturer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($lecturer->staff_name); ?>"><?php echo e($lecturer->staff_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <hr>
                                <div class="w-50 py-2">
                                    <button class="btn btn-primary w-100">ADD </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>


            </div>
        </div>

    </section>
    
</body>

<script>

</script>

</html><?php /**PATH C:\xampp\htdocs\first_school-master\first_school-master\resources\views//admin/admin_studs.blade.php ENDPATH**/ ?>