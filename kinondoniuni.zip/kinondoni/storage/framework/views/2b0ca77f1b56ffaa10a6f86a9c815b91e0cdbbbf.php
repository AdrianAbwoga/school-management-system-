<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>

    <!-- Fontawesome icons cdn link -->
    <script src="https://kit.fontawesome.com/db540a34d6.js" crossorigin="anonymous"></script>

    <link rel="stylesheet" href="/css/student.css">
    <title>kinondoni</title>
</head>

<body>
    <nav class="main-nav w-100">
        <div class="logo-div">
            <img src="/images/logo2.png" alt="">
        </div>

        <div class="categories w-75">
            <div class=""></div>
            <div class=""></div>
            <div class=""></div>
            <a href="<?php echo e(route('teacher')); ?>" class="w-100"><button class="nav_btn w-100"><span class="hov"></span> BACK</button></a>

            <div class="menu-div">
                <h3 class="ps-4"><?php echo e($LoggedUserInfo['staff_name']); ?></h3>
            </div>
        </div>
    </nav>
    <section class="unit w-100">
        
        </div>
        <section class="first">

        <div class="content w-100 m-0 p-2">
            <div class="header">
                <h4>POST WORK</h4>
                <hr>
            </div>
            <?php if(Session::get('success')): ?>
            <div class="alert alert-success">
                <?php echo e(Session::get('success')); ?>

            </div>
            <?php endif; ?>

            <?php if(Session::get('fail')): ?>
            <div class="alert alert-danger">
                <?php echo e(Session::get('fail')); ?>

            </div>
            <?php endif; ?>
            <form action="<?php echo e(url('add-work/'.$unit->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-input p-2 w-100">
                    <label for="header">TITLE:</label>
                    <input type="text" required name="cwork_head" class="form-control w-75">
                </div>
                <div class="form-input p-2 w-100">
                    <label for="header">OVERVIEW:</label>
                    <textarea name="cwork_desc" required class="form-control w-75" id="" rows="4"></textarea>
                </div>
                <div class="form-input p-2 w-100">
                    <button class="btn btn-dark">
                        ADD 
                    </button>
                </div>


            </form>

        </div>
</section>
        <?php $__currentLoopData = $unit_coursework; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="content w-100">
            <h3><?php echo e($item->cwork_head); ?></h3>
            <p><?php echo e($item->cwork_desc); ?></p>
            <a href="<?php echo e(url('delete-work/'.$item->id)); ?>"><button class="btn btn-outline-danger">REMOVE</button></a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </section>
    
</body>

</html><?php /**PATH C:\xampp\htdocs\first_school-master\first_school-master\resources\views//lecturer/unit.blade.php ENDPATH**/ ?>